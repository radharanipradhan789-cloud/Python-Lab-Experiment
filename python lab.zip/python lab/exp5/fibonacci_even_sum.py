fib = []
a, b = 0, 1

# Generate Fibonacci numbers up to 1000
while a <= 1000:
    fib.append(a)
    a, b = b, a + b

print("Fibonacci Series:", fib)

# Find sum of even values
sum_even = 0
for num in fib:
    if num % 2 == 0:
        sum_even += num

print("Sum of even-valued terms:", sum_even)