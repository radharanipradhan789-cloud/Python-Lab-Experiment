celsius_list = [0, 10, 20, 30, 40]

fahrenheit = []

for c in celsius_list:
    f = (9/5) * c + 32
    fahrenheit.append(f)

print("Fahrenheit:", fahrenheit)