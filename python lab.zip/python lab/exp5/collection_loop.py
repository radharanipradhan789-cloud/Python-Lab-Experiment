# List
lst = [1, 2, 3, 4, 5]

# Tuple
tup = (10, 20, 30, 40, 50)

# Dictionary
d = {"name": "Radha", "roll": 278}

# Set
s = {1, 2, 3, 4, 5}

# Loop through list
for i in lst:
    print("List value:", i)

# Loop through tuple
for i in tup:
    print("Tuple value:", i)

# Loop through dictionary
for key, val in d.items():
    print("Dictionary:", key, ":", val)

# Loop through set
for i in s:
    print("Set value:", i)