numbers = []

n = int(input("Enter number of elements: "))

for i in range(n):
    num = int(input("Enter element: "))
    numbers.append(num)

# Remove duplicates and sort
unique_numbers = list(set(numbers))
unique_numbers.sort()

print("List after removing duplicates and sorting:")
print(unique_numbers)