class Bank:
    # Constructor
    def __init__(self, ano, holder):
        self.ano = ano             # Account Number
        self.holder = holder       # Account Holder Name
        self.balance = 0           # Initial balance

    # Deposit method
    def deposit(self, amount):
        self.balance += amount
        print(f"Deposited {amount}. Current Balance: {self.balance}")

    # Withdraw method
    def withdraw(self, amount):
        if amount > self.balance:
            print("Insufficient balance!")
        else:
            self.balance -= amount
            print(f"Withdrew {amount}. Current Balance: {self.balance}")

    # Display account details
    def display(self):
        print(f"Account No: {self.ano}, Holder: {self.holder}, Balance: {self.balance}")


# Example usage
if __name__ == "__main__":
    obj = Bank(10, "Ravi")
    obj.deposit(100)      # Deposit 100
    obj.withdraw(50)      # Withdraw 50
    obj.display()         # Show account details