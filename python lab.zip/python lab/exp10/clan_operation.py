class Clan:
    # Constructor
    def __init__(self, data1, data2):
        self.data1 = data1
        self.data2 = data2

    # Addition
    def addition(self):
        print("Addition:", self.data1 + self.data2)

    # Subtraction
    def subtraction(self):
        print("Subtraction:", self.data1 - self.data2)

    # Multiplication
    def multiplication(self):
        print("Multiplication:", self.data1 * self.data2)

    # Division
    def division(self):
        if self.data2 != 0:
            print("Division:", self.data1 / self.data2)
        else:
            print("Cannot perform division by zero")


# Example usage
if __name__ == "__main__":
    obj = Clan(10, 12)
    obj.addition()        # 10 + 12 = 22
    obj.subtraction()     # 10 - 12 = -2
    obj.multiplication()  # 10 * 12 = 120
    obj.division()        # 10 / 12 = 0.8333...