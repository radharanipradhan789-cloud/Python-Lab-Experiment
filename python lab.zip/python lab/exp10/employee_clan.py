class Employee:
    # Parameterized constructor
    def __init__(self, empid, ename, bp):
        self.empid = empid
        self.ename = ename
        self.bp = bp  # Basic pay
        self.ta = 0   # Travel allowance
        self.da = 0   # Dearness allowance
        self.gp = 0   # Gross pay

    # Method to calculate TA, DA, and Gross Pay
    def calc(self):
        self.ta = self.bp * 10 / 100   # 10% of basic pay
        self.da = self.bp * 40 / 100   # 40% of basic pay
        self.gp = self.bp + self.ta + self.da

    # Method to display employee details
    def disp(self):
        print(f"ID: {self.empid}, Name: {self.ename}, Basic Pay: {self.bp}, TA: {self.ta}, DA: {self.da}, Gross Pay: {self.gp}")


# Example usage
if __name__ == "__main__":
    # Create an employee object
    emp = Employee(1, "Radharani Pradhan", 20000)
    emp.calc()       # Calculate allowances and gross pay
    emp.disp()       # Display employee details