class Product:
    # Constructor
    def __init__(self, pid, pname, quantity, price):
        self.pid = pid         # Product ID
        self.pname = pname     # Product Name
        self.quantity = quantity
        self.price = price
        self.total_amount = 0  # Total amount (quantity * price)

    # Calculate total
    def total(self):
        self.total_amount = self.quantity * self.price

    # Display product details
    def display(self):
        print(f"ID: {self.pid}, Name: {self.pname}, Quantity: {self.quantity}, Price: {self.price}, Total: {self.total_amount}")


# Example usage
if __name__ == "__main__":
    obj = Product(100, "Books", 12, 320)
    obj.total()     # Calculate total amount
    obj.display()   # Display product details