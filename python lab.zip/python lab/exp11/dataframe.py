import pandas as pd

# Create a dictionary with data
data = {
    'Name': ['Alice', 'Bob', 'Charlie'],
    'Age': [25, 30, 35],
    'City': ['New York', 'San Francisco', 'Los Angeles']
}

# Create a DataFrame
df = pd.DataFrame(data)

# Display the entire DataFrame
print("DataFrame:")
print(df)

# Display the 'Age' column
print("\nIn Age column:")
print(df['Age'])

# Display the row at index 1
print("\nRow at index 1:")
print(df.iloc[1])