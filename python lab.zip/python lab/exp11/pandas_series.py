import pandas as pd

# Create a pandas series
data = [10, 20, 30]
labels = ['a', 'b', 'c']

series = pd.Series(data, index=labels)
print("Pandas Series:\n", series)