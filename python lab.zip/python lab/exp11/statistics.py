import numpy as np

# Create array
arr = np.array([1, 2, 3])
print("Array:", arr)

# Statistical operations
print("Max:", arr.max())
print("Min:", arr.min())
print("Sum:", arr.sum())
print("Product:", arr.prod())

# Broadcasting example
print("Broadcast result (arr + 5):", arr + 5)