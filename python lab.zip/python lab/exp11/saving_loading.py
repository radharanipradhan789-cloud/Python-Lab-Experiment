import numpy as np

# Create array
arr = np.array([1, 2, 3, 4])

# Save array to file
np.save('my_array.npy', arr)

# Load array from file
loaded_arr = np.load('my_array.npy')
print("Loaded array:", loaded_arr)