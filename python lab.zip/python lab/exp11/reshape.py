import numpy as np

# Create an array
arr = np.array([[1, 2, 3], [4, 5, 6]])
print("Original array:\n", arr)

# Shape of the array
print("Shape of array:", arr.shape)

# Reshape the array
meshaped = arr.reshape(3, 2)
print("Reshaped array (3x2):\n", meshaped)