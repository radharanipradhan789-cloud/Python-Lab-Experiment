import numpy as np

# Experiment 11 - Part 3: Array Properties and Functions
print("=== Part 3: Array Properties and Functions ===")

# Ones array
ones_arr = np.ones((2,3))
print("Ones Array:\n", ones_arr)

# Zeros array
zeros_arr = np.zeros((2,5))
print("Zeros Array:\n", zeros_arr)

# Empty array
empty_arr = np.empty((2,3))
print("Empty Array:\n", empty_arr)

# Example 2D array
arr = np.array([[1,2,3],[4,5,6]])
print("Example 2D Array:\n", arr)
print("Shape:", arr.shape)
print("Size:", arr.size)
print("Number of Dimensions:", arr.ndim)