import numpy as np

print("=== Part 1: ndarray, Indexing, and Slicing ===")

arr = np.array([[1, 2, 3], [4, 5, 6]])
print("Array:\n", arr)

# Accessing elements
print("Element at (0,1):", arr[0,1])   # first row, second column
print("Row 1:", arr[1])                # second row
print("Column 2:", arr[:,2])           # third column
