import pandas as pd

# Create a dictionary with data
data = {
    'Math': [90, 85, 80, 95],
    'Science': [68, 82, 85, 90],
    'English': [78, 75, 80, 85]
}

# Create a DataFrame
df = pd.DataFrame(data)

# Display the DataFrame
print("Data Frame:")
print(df)

# Calculate correlation matrix
correlation = df.corr()

# Display correlation matrix
print("\nCorrelation Matrix:")
print(correlation)