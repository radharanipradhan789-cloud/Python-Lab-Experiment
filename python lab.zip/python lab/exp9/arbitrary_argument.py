def total(*nums):
    print("Sum =", sum(nums))

total(10, 20, 30)
total(5, 15)