def Student(name, course):
    print("Name:", name)
    print("Course:", course)

Student(course="Python", name="Anu")