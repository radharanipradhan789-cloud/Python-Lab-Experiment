def employee(**details):
    # Loop through all keyword arguments
    for k, v in details.items():
        print(k, ":", v)

# Calling the function with keyword arguments
employee(name="Kindi", id=101, dept="IT")