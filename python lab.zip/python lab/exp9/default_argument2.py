def bill(amount=100):
    print("Bill Amount:", amount)

bill(500)   # Passed value overrides default
bill()      # Uses default value