filename = "sample.txt"
with open(filename, "w") as file:  # w = write mode
    file.write("Hello World\n")