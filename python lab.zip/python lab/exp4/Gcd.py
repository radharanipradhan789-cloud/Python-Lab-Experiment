def gcd(x, y):
    while y:
        x, y = y, x % y
    return x

a = int(input("Enter first number: "))
b = int(input("Enter second number: "))
c = int(input("Enter third number: "))

g = gcd(gcd(a, b), c)

print("GCD =", g)