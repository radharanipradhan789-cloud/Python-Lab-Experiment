num = int(input("Enter a number: "))

rev = 0
n=num
while (n!=0):
    rem = n % 10
    rev = rev * 10 + rem
    n //= 10

print(f"The reverse of {num} is {rev}")