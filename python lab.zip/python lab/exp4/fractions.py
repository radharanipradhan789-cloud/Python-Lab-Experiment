for i in range(2, 101):
    value = 1 / i
    print(f"1/{i} = {value}")