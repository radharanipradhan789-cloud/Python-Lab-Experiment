num = int(input("Enter a number: "))

original = num
rev = 0

while num > 0:
    rem = num % 10
    rev = rev * 10 + rem
    num //= 10

if rev == original:
    print("Palindrome number")
else:
    print("Not a palindrome number")