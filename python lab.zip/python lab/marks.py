physics = 80
chemistry = 79
maths =90
sum_marks = physics + chemistry + maths
percentage = (sum_marks / 300) * 100

print("\n--- Marks Details ---")
print("Physics:", physics)
print("Chemistry:", chemistry)
print("Maths:", maths)
print("Sum:", sum_marks)
print("Percentage:", percentage)