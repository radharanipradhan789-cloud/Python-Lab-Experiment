d = int(input("Enter a digit (0 to 6): "))

if d == 0:
    print("Sunday")
elif d == 1:
    print("Monday")
elif d == 2:
    print("Tuesday")
elif d == 3:
    print("Wednesday")
elif d == 4:
    print("Thursday")
elif d == 5:
    print("Friday")
elif d == 6:
    print("Saturday")
else:
    print("Invalid digit! Enter between 0 and 6.")