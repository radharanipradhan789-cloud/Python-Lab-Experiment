s = input("Enter a string: ")

# Remove spaces and convert to lowercase
clean = s.replace(" ", "").lower()

if clean == clean[::-1]:
    print("Palindrome")
else:
    print("Not Palindrome")