ch = input("Enter a letter: ")

# Check valid input
if len(ch) != 1 or not ch.isalpha():
    print("Invalid input. Please enter a single alphabet.")
else:
    ch = ch.lower()
    
    if ch in ['a', 'e', 'i', 'o', 'u']:
        print("It is a vowel.")
    else:
        print("It is a consonant.")