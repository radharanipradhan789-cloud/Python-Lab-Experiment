marks = []

# Input marks for 5 subjects
for i in range(5):
    m = float(input(f"Enter marks for Subject {i+1} (0-50): "))
    
    if m < 0 or m > 50:
        print("Invalid marks! Should be between 0 and 50.")
        exit()
    
    marks.append(m)

# Calculate total and percentage
total = sum(marks)
percentage = (total / (5 * 50)) * 100

print("Percentage:", percentage)

# Grade calculation
if percentage >= 90:
    grade = "O"
elif percentage >= 80:
    grade = "E"
elif percentage >= 70:
    grade = "A"
elif percentage >= 60:
    grade = "B"
elif percentage >= 50:
    grade = "C"
elif percentage >= 40:
    grade = "D"
else:
    grade = "F"

print("Grade:", grade)