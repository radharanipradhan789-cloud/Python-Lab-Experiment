a=10
b=20
print ("The number before swapping is :",a ,b)
temp =a
a =b 
b =temp
print ("The number after swapping is:",a,b)
