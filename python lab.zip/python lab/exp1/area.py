r = 5
pi = 3.14

area = pi * r * r
perimeter = 2 * pi * r

print("Area:", area)
print("Perimeter:", perimeter)