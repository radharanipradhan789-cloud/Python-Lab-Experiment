a=10
b=20
a=a+b
b=a-b
a=a-b
print ("The number after swapping is:",a,b)
