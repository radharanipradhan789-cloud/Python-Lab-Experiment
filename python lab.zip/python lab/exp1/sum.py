a = int(input("Enter first number: "))
b = int(input("Enter second number: "))

s = a + b
p = a * b

print("Sum:", s)
print("Product:", p)