name = input("Enter your name: ")
age = input("Enter your age: ")
address = input("Enter your address: ")

print("my Name is :", name)
print("my Age is:", age)
print("my Address is:", address)