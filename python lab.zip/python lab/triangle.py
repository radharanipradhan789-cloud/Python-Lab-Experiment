import math

a = float(input("Enter side a: "))
b = float(input("Enter side b: "))
c = float(input("Enter side c: "))

perimeter = a + b + c
s = perimeter / 2

area = math.sqrt(s * (s - a) * (s - b) * (s - c))

print("The perimeter of triangle:", perimeter)
print("The area of triangle:", area)