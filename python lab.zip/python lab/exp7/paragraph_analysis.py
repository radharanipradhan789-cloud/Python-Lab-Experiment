import string

para = input("Enter a paragraph: ")

# Remove punctuation
for ch in string.punctuation:
    para = para.replace(ch, "")

# Split into words
words = para.split()

# 1) Count words
word_count = len(words)

# 2) Count palindrome words
pal_count = 0
for w in words:
    w = w.lower()
    if w == w[::-1] and len(w) > 1:
        pal_count += 1

# 3) Print each word in reverse order
print("Each word in reverse order:")
for w in words:
    print(w[::-1])

# Output
print("\nTotal number of words:", word_count)
print("Number of palindrome words:", pal_count)