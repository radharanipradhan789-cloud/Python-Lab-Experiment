n = int(input("Enter the value of n: "))

list1 = []

for i in range(1, n + 1):
    list1.append(i)

total = 0
largest = list1[0]
smallest = list1[0]

for num in list1:
    total += num

    if num > largest:
        largest = num

    if num < smallest:
        smallest = num

average = total / n

list2 = []
for num in list1:
    if num % 3 != 0:
        list2.append(num)

print("First list:", list1)
print("Sum =", total)
print("Average =", average)
print("Largest =", largest)
print("Smallest =", smallest)
print("Second list (not divisible by 3):", list2)