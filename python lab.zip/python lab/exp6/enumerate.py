# Input sentence
sentence = input("Enter a sentence: ")  # Example: "Python is easy"

# Split sentence into words
list1 = sentence.split()
print("\nWords in the sentence:", list1)

# Display words with index using enumerate
print("\nWords with their index:")
for index, word in enumerate(list1):
    print(index, word)

# Create another list of numbers
list2 = list(range(1, len(list1)+1))  # e.g., [1, 2, 3, ...] for each word
print("\nList of numbers:", list2)

# Combine the two lists using zip
combined_list = list(zip(list1, list2))
print("\nCombined list using zip():", combined_list)