# Create the first dictionary
dict1 = {}
n1 = int(input("Enter number of elements for the first dictionary: "))

for i in range(n1):
    key = input("Enter key: ")
    value = input("Enter value: ")
    dict1[key] = value

# Create the second dictionary
dict2 = {}
n2 = int(input("\nEnter number of elements for the second dictionary: "))

for i in range(n2):
    key = input("Enter key: ")
    value = input("Enter value: ")
    dict2[key] = value

# Display both dictionaries
print("\nFirst Dictionary:", dict1)
print("Second Dictionary:", dict2)

# Create new dictionary: values of dict1 as keys, values of dict2 as values
new_dict = {}
values1 = list(dict1.values())
values2 = list(dict2.values())
min_len = min(len(values1), len(values2))

for i in range(min_len):
    new_dict[values1[i]] = values2[i]

print("\nNew Dictionary (values of dict1 as keys, values of dict2 as values):")
print(new_dict)