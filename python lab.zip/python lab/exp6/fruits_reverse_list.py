# Original list of fruits
fruits = ["apple", "banana", "mango", "orange", "grapes"]

# Display original list
print("Original list:", fruits)

# Display elements from last to first
print("\nList from last to first:")
for i in range(len(fruits)-1, -1, -1):
    print(fruits[i])

# Display length of each element
print("\nLength of each element:")
for fruit in fruits:
    print(f"{fruit} = {len(fruit)}")

# Create another list with reverse of each element
reverse_list = []
for fruit in fruits:
    reverse_list.append(fruit[::-1])

print("\nList with reverse of each element:")
print(reverse_list)
