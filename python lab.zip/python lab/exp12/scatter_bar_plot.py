import matplotlib.pyplot as plt

# Data
x = [1, 2, 3, 4]
y = [10, 20, 25, 30]

# Create line plot
plt.plot(x, y, linestyle='--', color='r', marker='o', label='Data line')

# Add labels and title
plt.xlabel("X-axis")
plt.ylabel("Y-axis")
plt.title("Simple Line Plot")

# Add legend and grid
plt.legend()
plt.grid(True)

# Display the plot
plt.show()