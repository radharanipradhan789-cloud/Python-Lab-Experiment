import matplotlib.pyplot as plt

# Data
data = [122, 87, 5, 43, 56, 13, 55, 54, 20, 51, 5]

# Histogram
plt.hist(data, bins=5, color='purple', label='Histogram Data')
plt.title("Histogram")
plt.xlabel("Bins")
plt.ylabel("Frequency")
plt.legend()
plt.show()

# Box plot
plt.boxplot(data)
plt.title("Box Plot")
plt.ylabel("Values")
plt.show()