sent = input("Enter your sentence: ")

print("Reversed sentence:", sent[::-1])