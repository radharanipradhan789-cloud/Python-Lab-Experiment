stn = " hi nam hi shyam hi mam "

# Remove leading & trailing spaces
stn = stn.strip()

# Replace "hi" with "Hello"
stn = stn.replace("hi", "Hello")

print("The sentence is:", stn)