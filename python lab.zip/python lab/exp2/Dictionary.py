d = {
    "name": "Aditi",
    "roll": 93,
    "subject": "Python"
}

# Display keys
print("Keys:", d.keys())

# Display values
print("Values:", d.values())

# Display key-value pairs
for key, value in d.items():
    print(key, ":", value)