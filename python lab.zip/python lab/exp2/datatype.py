i = 10
stn = "hello"
com = [2]
f = 3.14
b = True

print(i, type(i))
print(stn, type(stn))
print(com, type(com))
print(f, type(f))
print(b, type(b))