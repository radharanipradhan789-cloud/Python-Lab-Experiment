fruits = ["apple", "banana", "mango", "lemon", "pineapple"]

print("List of fruits:", fruits)