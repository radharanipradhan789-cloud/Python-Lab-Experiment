stn = "Good morning friends, how are you all"

# Reverse sentence
print("Reverse:", stn[::-1])

# Split into words
words = stn.split()
print("List of words:", words)