import math

p = float(input("Enter the principal amount: "))
r = float(input("Enter the rate: "))
t = float(input("Enter the time: "))

# Simple Interest
si = (p * r * t) / 100

# Compound Interest
ci = p * (1 + r/100) ** t - p

print("Simple Interest:", si)
print("Compound Interest:", ci)