t = (1, "aditi", "python", 89)

print("Tuple elements:", t)