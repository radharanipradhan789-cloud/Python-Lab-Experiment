stn = "hello world"

print("Upper case:", stn.upper())
print("Lower case:", stn.lower())
print("Capitalized:", stn.capitalize())
print("Length:", len(stn))